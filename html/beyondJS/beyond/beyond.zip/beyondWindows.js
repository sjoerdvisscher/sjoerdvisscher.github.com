/*
   BeyondWindows.JS
   by Dan Shappir and Sjoerd Visscher
   For more information see http://w3future.com/html/beyondJS
*/
if ( typeof(beyondLazyVer) !== "number" || beyondLazyVer < 0.95 )
	alert("beyondWindows requires BeyondLazy JS library ver 0.95 or higher");
if ( typeof(beyondStreamsVer) !== "number" || beyondStreamsVer < 0.91 )
	alert("beyonWindows requires beyondStreams JS library ver 0.91 or higher");
var beyondWindowsVer = 0.9;

var isWScript = typeof(WScript) == "object";

function commandLine(index) {
	var args;
	if ( isWScript ) {		// WScript
		args = new Array(WScript.Arguments.length+1);
		args[0] = WScript.ScriptFullName;
		for ( var i = 1 ; i < args.length ; ++i )
			args[i] = WScript.Arguments(i-1);
	}
	else {					// HTA
		args = new Array;
		var reArgs = /(?:([^"\s]\S*)|"([^"]*)")/;
		for ( var i = 0 ; i < document.all.length ; ++i )
			if ( document.all[i].tagName == "APPLICATION" ) {
				var hta = document.all[i];
				reArgs.iterate(hta.commandLine, function(a) {
					args.push(a[1].length ? a[1] : a[2]);
				});
				break;
			}
	}
	commandLine = function(index) {
		return typeof(index) != "undefined" ? args[index] : args;
	};
	return commandLine(index);
}

var File = {

	systemObject : function() {
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		this.systemObject = function() {
			return fso;
		};
		return fso;
	},

	read : function(file, cache) {
		if ( typeof(file) == "string" )
			file = this.systemObject().GetFile(file);
		var rf = function(item) {
			var stream = item[1] ? 
				item[1] :
				typeof(rf.file.OpenAsTextStream) != "undefined" ? 
					rf.file.OpenAsTextStream(1) : 
					rf.file;
			if ( stream.AtEndOfStream ) {
				stream.Close();
				return [];
			}
			return [ stream.ReadLine(), stream ];
		}.lazy();
		if ( cache )
			rf = rf.cached();
		rf.file = file;
		return rf;
	},
	write : function(file, overwrite) {
		var st = new Stream(typeof(file) == "string" ?
			this.systemObject().OpenTextFile(file, overwrite ? 2 : 8, true) :
			typeof(file.OpenAsTextStream) != "undefined" ?
				file.OpenAsTextStream(overwrite ? 2 : 8) :
				file);
		var handle = st.foreach(function(v, stream) {
			if ( isDefined(v) )
				stream.WriteLine(v);
		});
		st.stop = function() {
			this.detach(handle);
			this.owner.Close();
		};
		return st;
	},
	process : function(input, output, f, append) {
		if ( !f )
			f = Function.NOP;
		else if ( f.constructor === RegExp ) {
			var re = f;
			f = function(line) {
				if ( re.test(line) )
					return line;
			};
		}
		return this.write(output, !append).extend(this.read(input).collect(f));
	},

	drives : function() {
		return Lazy.from(new Enumerator(this.systemObject().Drives));
	},
	subFolders : function(folder) {
		if ( typeof(folder) == "string" )
			folder = this.systemObject().GetFolder(folder);
		return Lazy.from(new Enumerator(folder.SubFolders));
	},
	files : function(folder) {
		if ( typeof(folder) == "string" )
			folder = this.systemObject().GetFolder(folder);
		return Lazy.from(new Enumerator(folder.files));
	},
	recurse : function(folder) {
		var recurse = Function.from(this, arguments.callee);
		return this.files(folder).extend(this.subFolders(folder).collect(recurse)).spread();
	},

	createFolder : function(folder) {
	       if ( !this.systemObject().FolderExists(folder) )
		       this.systemObject().CreateFolder(folder);
	}
};

if ( isWScript ) {

	alert = function(sMessage) {
		WScript.Echo(sMessage);
	};

	shellObject = function() {
		var wss = WScript.CreateObject("WScript.Shell");
		shellObject = function() {
			return wss;
		};
		return wss;
	};
	
	File.StdIn = File.read(WScript.StdIn);
	File.StdOut = File.write(WScript.StdOut);
	File.StdErr = File.write(WScript.StdErr);
	
}